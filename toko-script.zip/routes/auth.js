const express = require('express');
const router = express.Router();
const bcrypt = require('bcrypt');
const { getDB } = require('../db');

router.get('/login', (req, res) => {
    res.render('login', { error: null, redirect: req.query.redirect || '/' });
});

router.post('/login', async (req, res) => {
    const { username, password, redirect } = req.body;
    const db = getDB();
    const user = await db.get('SELECT * FROM users WHERE username = ? OR email = ?', [username, username]);
    if (!user) {
        return res.render('login', { error: 'Username/email tidak ditemukan', redirect: redirect || '/' });
    }
    const match = await bcrypt.compare(password, user.password);
    if (!match) {
        return res.render('login', { error: 'Password salah', redirect: redirect || '/' });
    }
    req.session.userId = user.id;
    req.session.username = user.username;
    res.redirect(redirect || '/');
});

router.get('/register', (req, res) => {
    res.render('register', { error: null });
});

router.post('/register', async (req, res) => {
    const { username, email, password, confirm_password } = req.body;
    if (password !== confirm_password) {
        return res.render('register', { error: 'Password tidak cocok' });
    }
    const db = getDB();
    const existing = await db.get('SELECT id FROM users WHERE username = ? OR email = ?', [username, email]);
    if (existing) {
        return res.render('register', { error: 'Username atau email sudah terdaftar' });
    }
    const hashed = await bcrypt.hash(password, 10);
    await db.run('INSERT INTO users (username, email, password) VALUES (?, ?, ?)', [username, email, hashed]);
    res.redirect('/login');
});

router.get('/logout', (req, res) => {
    req.session.destroy();
    res.redirect('/');
});

module.exports = router;