const express = require('express');
const router = express.Router();
const { getDB } = require('../db');
const { requireAdmin } = require('../middleware/auth');

router.get('/admin/login', (req, res) => {
    res.render('admin/login', { error: null });
});

router.post('/admin/login', (req, res) => {
    const { username, password } = req.body;
    if (username === process.env.ADMIN_USERNAME && password === process.env.ADMIN_PASSWORD) {
        req.session.isAdmin = true;
        res.redirect('/admin/dashboard');
    } else {
        res.render('admin/login', { error: 'Invalid credentials' });
    }
});

router.get('/admin/dashboard', requireAdmin, async (req, res) => {
    const db = getDB();
    const totalOrders = await db.get('SELECT COUNT(*) as count FROM orders');
    const totalRevenue = await db.get('SELECT SUM(amount) as total FROM orders WHERE status = "success"');
    const recentOrders = await db.all('SELECT * FROM orders ORDER BY created_at DESC LIMIT 10');
    const products = await db.all('SELECT * FROM products');
    res.render('admin/dashboard', { 
        totalOrders: totalOrders.count,
        totalRevenue: totalRevenue.total || 0,
        recentOrders,
        products
    });
});

router.post('/admin/product/add', requireAdmin, async (req, res) => {
    const { name, description, price, type, file_path } = req.body;
    const db = getDB();
    await db.run('INSERT INTO products (name, description, price, type, file_path) VALUES (?, ?, ?, ?, ?)',
        [name, description, price, type, file_path]);
    res.redirect('/admin/dashboard');
});

router.post('/admin/product/delete/:id', requireAdmin, async (req, res) => {
    const db = getDB();
    await db.run('DELETE FROM products WHERE id = ?', req.params.id);
    res.redirect('/admin/dashboard');
});

module.exports = router;