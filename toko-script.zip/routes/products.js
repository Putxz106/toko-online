const express = require('express');
const router = express.Router();
const { getDB } = require('../db');

// Halaman daftar produk
router.get('/products', async (req, res) => {
    const db = getDB();
    const products = await db.all('SELECT * FROM products WHERE is_active = 1');
    res.render('products', { products, user: req.session });
});

// Detail produk
router.get('/product/:id', async (req, res) => {
    const db = getDB();
    const product = await db.get('SELECT * FROM products WHERE id = ? AND is_active = 1', req.params.id);
    if (!product) return res.status(404).send('Produk tidak ditemukan');
    res.render('checkout', { product, user: req.session, error: null });
});

module.exports = router;