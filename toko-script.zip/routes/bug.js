const express = require('express');
const router = express.Router();
const { getDB } = require('../db');
const { sendToTelegram } = require('../telegram');
const { requireLogin } = require('../middleware/auth');

router.get('/bug', requireLogin, (req, res) => {
    res.render('bug', { user: req.session, success: null, error: null });
});

router.post('/bug', requireLogin, async (req, res) => {
    const { subject, message } = req.body;
    if (!subject || !message) {
        return res.render('bug', { user: req.session, error: 'Subject dan pesan harus diisi', success: null });
    }
    const db = getDB();
    await db.run('INSERT INTO bug_reports (user_id, subject, message) VALUES (?, ?, ?)',
        [req.session.userId, subject, message]);
    
    // Kirim ke Telegram admin
    const bugText = `🐞 LAPORAN BUG\nUser: ${req.session.username} (ID: ${req.session.userId})\nSubject: ${subject}\nPesan: ${message}`;
    await sendToTelegram(bugText);
    
    res.render('bug', { user: req.session, success: 'Laporan terkirim. Terima kasih!', error: null });
});

module.exports = router;