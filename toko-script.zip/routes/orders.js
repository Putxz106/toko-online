const express = require('express');
const router = express.Router();
const { getDB } = require('../db');
const { createDeposit, checkDepositStatus } = require('../ramashop');
const { sendToTelegram } = require('../telegram');
const { requireLogin } = require('../middleware/auth');

// Halaman checkout (sudah di product detail, tapi kita buat endpoint beli)
router.post('/order/create', requireLogin, async (req, res) => {
    const { product_id } = req.body;
    const db = getDB();
    const product = await db.get('SELECT * FROM products WHERE id = ? AND is_active = 1', product_id);
    if (!product) {
        return res.status(404).json({ error: 'Produk tidak ditemukan' });
    }

    const orderId = 'ORD-' + Date.now() + '-' + Math.random().toString(36).substr(2, 6);
    const amount = product.price;

    // Buat deposit di Ramashop
    try {
        const deposit = await createDeposit(amount);
        // Simpan order
        await db.run(`
            INSERT INTO orders (order_id, user_id, product_id, amount, deposit_id, status)
            VALUES (?, ?, ?, ?, ?, 'pending')
        `, [orderId, req.session.userId, product.id, amount, deposit.depositId]);

        // Kirim notifikasi ke admin
        await sendToTelegram(`🆕 Order baru: ${orderId}\nUser: ${req.session.username}\nProduk: ${product.name}\nTotal: Rp ${amount.toLocaleString('id-ID')}\nDeposit ID: ${deposit.depositId}`);

        res.json({
            success: true,
            order_id: orderId,
            depositId: deposit.depositId,
            qrImage: deposit.qrImage,
            qrString: deposit.qrString,
            totalAmount: deposit.totalAmount
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Gagal membuat payment, coba lagi' });
    }
});

// Halaman pembayaran (menampilkan QR & polling)
router.get('/payment/:orderId', requireLogin, async (req, res) => {
    const db = getDB();
    const order = await db.get('SELECT * FROM orders WHERE order_id = ? AND user_id = ?', 
        [req.params.orderId, req.session.userId]);
    if (!order) return res.status(404).send('Order tidak ditemukan');
    
    // Ambil depositId dari order
    const depositId = order.deposit_id;
    if (!depositId) return res.status(400).send('Deposit ID tidak valid');

    // Kita butuh QR image dari Ramashop? Tidak disimpan. Tapi bisa generate ulang? Tidak bisa. 
    // Alternatif: Saat create deposit, kita simpan qrImage di session atau di order. Kita simpan di kolom download_link sementara.
    // Agar tidak ribet, kita simpan qrImage di order.download_link sebagai JSON.
    let qrData = {};
    try {
        qrData = JSON.parse(order.download_link || '{}');
    } catch(e) { qrData = {}; }
    
    res.render('payment', { 
        order, 
        qrImage: qrData.qrImage || '',
        totalAmount: order.amount,
        user: req.session
    });
});

// API cek status payment (untuk polling)
router.get('/api/order/status/:orderId', requireLogin, async (req, res) => {
    const db = getDB();
    const order = await db.get('SELECT * FROM orders WHERE order_id = ? AND user_id = ?', 
        [req.params.orderId, req.session.userId]);
    if (!order) return res.json({ status: 'not_found' });
    
    if (order.status === 'success') {
        return res.json({ status: 'success', download_link: order.download_link });
    }
    
    // Cek status deposit ke Ramashop
    const depositStatus = await checkDepositStatus(order.deposit_id);
    if (depositStatus === 'success') {
        // Payment sukses, update order
        const product = await db.get('SELECT file_path FROM products WHERE id = ?', order.product_id);
        const downloadLink = product ? product.file_path : null;
        await db.run(`UPDATE orders SET status = 'success', paid_at = CURRENT_TIMESTAMP, download_link = ? WHERE order_id = ?`, 
            [downloadLink, order.order_id]);
        
        // Kirim notifikasi ke admin
        await sendToTelegram(`✅ Pembayaran sukses!\nOrder: ${order.order_id}\nUser: ${req.session.username}\nDownload link: ${downloadLink}`);
        
        return res.json({ status: 'success', download_link: downloadLink });
    } else if (depositStatus === 'already') {
        // Sudah diproses sebelumnya
        const product = await db.get('SELECT file_path FROM products WHERE id = ?', order.product_id);
        const downloadLink = product ? product.file_path : null;
        if (order.status !== 'success') {
            await db.run(`UPDATE orders SET status = 'success', paid_at = CURRENT_TIMESTAMP, download_link = ? WHERE order_id = ?`, 
                [downloadLink, order.order_id]);
        }
        return res.json({ status: 'success', download_link: downloadLink });
    }
    
    res.json({ status: 'pending' });
});

// Download file zip setelah payment sukses
router.get('/download/:orderId', requireLogin, async (req, res) => {
    const db = getDB();
    const order = await db.get('SELECT * FROM orders WHERE order_id = ? AND user_id = ?', 
        [req.params.orderId, req.session.userId]);
    if (!order || order.status !== 'success' || !order.download_link) {
        return res.status(403).send('Akses ditolak atau file tidak tersedia');
    }
    // Path file zip di server (asumsikan ada di folder public)
    const filePath = path.join(__dirname, '../public', order.download_link);
    if (!fs.existsSync(filePath)) {
        return res.status(404).send('File tidak ditemukan');
    }
    res.download(filePath);
});

module.exports = router;