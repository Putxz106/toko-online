function requireLogin(req, res, next) {
    if (req.session && req.session.userId) {
        return next();
    }
    res.redirect('/login?redirect=' + encodeURIComponent(req.originalUrl));
}

function requireAdmin(req, res, next) {
    if (req.session && req.session.isAdmin) {
        return next();
    }
    res.redirect('/admin/login');
}

module.exports = { requireLogin, requireAdmin };