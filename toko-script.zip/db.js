const sqlite3 = require('sqlite3');
const { open } = require('sqlite');
const path = require('path');
const bcrypt = require('bcrypt');

let db;

async function initDB() {
    db = await open({
        filename: path.join(__dirname, 'toko_script.db'),
        driver: sqlite3.Database
    });

    // Users table
    await db.exec(`
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    `);

    // Products table
    await db.exec(`
        CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            description TEXT,
            price INTEGER NOT NULL,
            type TEXT NOT NULL,
            file_path TEXT NOT NULL,
            is_active INTEGER DEFAULT 1,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    `);

    // Orders / Transactions table
    await db.exec(`
        CREATE TABLE IF NOT EXISTS orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            order_id TEXT UNIQUE NOT NULL,
            user_id INTEGER NOT NULL,
            product_id INTEGER NOT NULL,
            amount INTEGER NOT NULL,
            deposit_id TEXT,
            status TEXT DEFAULT 'pending',
            download_link TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            paid_at DATETIME,
            FOREIGN KEY (user_id) REFERENCES users(id),
            FOREIGN KEY (product_id) REFERENCES products(id)
        )
    `);

    // Bug reports table
    await db.exec(`
        CREATE TABLE IF NOT EXISTS bug_reports (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            subject TEXT NOT NULL,
            message TEXT NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    `);

    // Insert sample products if empty
    const productCount = await db.get('SELECT COUNT(*) as count FROM products');
    if (productCount.count === 0) {
        // Buat folder uploads/scripts dulu secara manual
        await db.run(`
            INSERT INTO products (name, description, price, type, file_path, is_active) VALUES
            ('WhatsApp Bot Script Basic', 'Script WA bot dengan auto-reply, anti spam, dan fitur dasar.', 150000, 'whatsapp', '/uploads/scripts/wa_basic.zip', 1),
            ('WhatsApp Bot Script Pro', 'Script WA bot multi-fiturnya. Support AI, database, dan webhook.', 350000, 'whatsapp', '/uploads/scripts/wa_pro.zip', 1),
            ('Telegram Bot Script Starter', 'Script Telegram bot dengan command handler dan inline keyboard.', 100000, 'telegram', '/uploads/scripts/tg_starter.zip', 1),
            ('Telegram Bot Script Enterprise', 'Script Telegram bot premium. Group management, payment integration.', 300000, 'telegram', '/uploads/scripts/tg_enterprise.zip', 1)
        `);
    }

    // Create default admin user if not exists (password: admin123)
    const adminExist = await db.get('SELECT * FROM users WHERE username = ?', 'admin');
    if (!adminExist) {
        const hashed = await bcrypt.hash('admin123', 10);
        await db.run('INSERT INTO users (username, email, password) VALUES (?, ?, ?)', 
            ['admin', 'admin@example.com', hashed]);
    }

    return db;
}

function getDB() {
    return db;
}

module.exports = { initDB, getDB };