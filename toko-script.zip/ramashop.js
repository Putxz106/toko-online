const axios = require('axios');

const API_URL = process.env.RAMASHOP_API_URL;
const API_KEY = process.env.RAMASHOP_API_KEY;

/**
 * Cek saldo akun Ramashop
 */
async function getBalance() {
    try {
        const response = await axios.get(`${API_URL}/balance`, {
            headers: { 'X-API-Key': API_KEY }
        });
        return response.data;
    } catch (error) {
        console.error('Ramashop balance error:', error.response?.data || error.message);
        throw new Error('Gagal cek saldo Ramashop');
    }
}

/**
 * Buat deposit QRIS untuk suatu transaksi
 * @param {number} amount - Jumlah dalam IDR
 * @returns {Promise<object>} { depositId, qrImage, qrString, totalAmount }
 */
async function createDeposit(amount) {
    try {
        const response = await axios.post(`${API_URL}/deposit/create`, 
            { amount, method: 'qris' },
            { headers: { 'X-API-Key': API_KEY, 'Content-Type': 'application/json' } }
        );
        if (response.data.success) {
            return {
                depositId: response.data.data.depositId,
                qrImage: response.data.data.qrImage,
                qrString: response.data.data.qrString,
                totalAmount: response.data.data.totalAmount,
                uniqueCode: response.data.data.uniqueCode
            };
        } else {
            throw new Error(response.data.message || 'Gagal membuat deposit');
        }
    } catch (error) {
        console.error('Create deposit error:', error.response?.data || error.message);
        throw new Error('Gagal membuat payment request');
    }
}

/**
 * Cek status deposit
 * @param {string} depositId 
 * @returns {Promise<string>} 'pending', 'success', 'already'
 */
async function checkDepositStatus(depositId) {
    try {
        const response = await axios.get(`${API_URL}/deposit/status/${depositId}`, {
            headers: { 'X-API-Key': API_KEY }
        });
        if (response.data.status === true) {
            return response.data.data.status; // 'pending', 'success', 'already'
        }
        return 'pending';
    } catch (error) {
        console.error('Check deposit status error:', error.message);
        return 'pending';
    }
}

module.exports = { getBalance, createDeposit, checkDepositStatus };